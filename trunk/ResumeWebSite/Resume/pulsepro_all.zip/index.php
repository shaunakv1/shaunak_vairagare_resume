<?php $page_title = "Home Page"; ?>
<?php $cur = "home"; ?>
<?php include_once("template/header.php"); ?>

<div id="main">
			
	<div class="row">
		<article class="twothird">		
			<?php include("pulsepro/data/blocks/Home.html"); ?>		
			<?php $gallery ="photos";  $max_img = "50"; include("pulsepro/includes/gallery.php"); ?>					</article>		
					
		<aside class="third">
			<div class="inner">
				<?php include("pulsepro/data/blocks/sidebar.html"); ?>
			</div>								
		</aside>
				
	</div>
		
	<ul id="blocks" class="block-three">
		<li>
			<div class="inner">
				<h4>Heading 1</h4>
					<p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
			</div>
		</li>
			
		<li>
			<div class="inner">
				<h4>Heading 2</h4>
				<p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
			</div>
		</li>
			
		<li>
			<div class="inner">
				<h4>Heading 3</h4>
				<p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
			</div>
		</li>					
	</ul>

</div>
		
<?php include_once("template/footer.php"); ?>