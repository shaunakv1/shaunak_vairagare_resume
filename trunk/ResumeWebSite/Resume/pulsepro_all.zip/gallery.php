<?php $page_title = "Photo Gallery"; ?>
<?php $cur = "gallery"; ?>
<?php include_once("template/header.php"); ?>

<div id="main">
			
	<div class="row">
		
		<article class="twothird">		
			<h1>Our Portfolio</h1>
			<?php $gallery ="photos";  $max_img = "50"; include("pulsepro/includes/gallery2.php"); ?>
		</article>		
					
		<aside class="third">
			<div class="inner">
				<?php include("pulsepro/data/blocks/sidebar.html"); ?>
			</div>								
		</aside>
				
	</div>
		
</div>

<?php include_once("template/footer.php"); ?>