<?php $page_title = "Blog"; ?>
<?php $cur = "blog"; ?>
<?php include_once("template/header.php"); ?>

<div id="main">
			
	<div class="row">
	
		<article class="twothird">		
			<?php include("pulsepro/includes/blog.php"); ?>
		</article>		
					
		<aside class="third">
			<div class="inner">
				<?php include("pulsepro/data/blocks/sidebar.html"); ?>
			</div>								
		</aside>
				
	</div>
		
</div>

<?php include_once("template/footer.php"); ?>