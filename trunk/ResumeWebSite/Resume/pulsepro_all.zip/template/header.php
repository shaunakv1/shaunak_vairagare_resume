<!DOCTYPE html>
<html>
<head>	
	<title><?php echo $page_title; ?></title>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
 
	<link rel="stylesheet" type="text/css" href="template/css/kube.css" />
	<link rel="stylesheet" type="text/css" href="template/css/style.css" />	
	
	<!--[if lt IE 9]>
	<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->		
	
</head>
<body>

	<div class="wrapper group">
	
		<header id="header">
			<img class="logo" src="template/img/logo.png">
			
			<nav id="nav">
				<ul>
					<li><a <?php if ($cur=="home") echo 'class="on"' ?> href="index.php">Home</a></li>
					<li><a <?php if ($cur=="about") echo 'class="on"' ?> href="about.php">About</a></li>
					<li><a <?php if ($cur=="gallery") echo 'class="on"' ?> href="gallery.php">Gallery</a></li>
					<li><a <?php if ($cur=="contact") echo 'class="on"' ?> href="contact.php">Contact</a></li>
					<li><a <?php if ($cur=="events") echo 'class="on"' ?> href="events.php">Events</a></li>
					<li><a <?php if ($cur=="blog") echo 'class="on"' ?> href="blog.php">Blog</a></li>
				</ul>			
			</nav>
							
		</header>