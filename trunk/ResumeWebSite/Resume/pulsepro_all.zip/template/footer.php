<footer id="footer">

<p class="copyright">&copy; Acme Inc. 2013</p>

<span class="soc-icons">
	<a href="#"><img src="template/img/twitter-icon.png" alt="Twitter" /></a>
	<a href="#"><img src="template/img/fb-icon.png" alt="Facebook" /></a>
	<a href="#"><img src="template/img/gplus-icon.png" alt="Google Plus" /></a>
	<a href="#"><img src="template/img/rss-icon.png" alt="RSS" /></a>
</span>

</footer>
	
	</div>
</body>
</html>