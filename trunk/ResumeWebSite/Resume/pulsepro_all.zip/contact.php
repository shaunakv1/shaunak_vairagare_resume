<?php $page_title = "Contact Us"; ?>
<?php $cur = "contact"; ?>
<?php include_once("template/header.php"); ?>

<div id="main">
			
	<div class="row">
	
		<article class="twothird">		
			<h1>Contact Us</h1>
			<p>Have a question? Send us an email below.</p>
			<?php include("pulsepro/includes/form.php"); ?>
		</article>		
					
		<aside class="third">
			<div class="inner">
				<?php include("pulsepro/data/blocks/sidebar.html"); ?>
			</div>								
		</aside>
				
	</div>
		
</div>

<?php include_once("template/footer.php"); ?>