<?php $page_title = "About"; ?>
<?php $cur = "about"; ?>
<?php include_once("template/header.php"); ?>

<div id="main">
			
	<div class="row">
		
		<!-- MAIN CONTENT AREA -->
		<article class="twothird">		
			<?php include("pulsepro/data/blocks/About.html"); ?>
		</article>		
		
		<!-- SIDEBAR -->			
		<aside class="third">
			<div class="inner">
				<?php include("pulsepro/data/blocks/sidebar.html"); ?>
			</div>								
		</aside>
				
	</div>
		
</div>

<?php include_once("template/footer.php"); ?>