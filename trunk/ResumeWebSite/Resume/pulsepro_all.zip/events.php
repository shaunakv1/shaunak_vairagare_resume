<?php $page_title = "Events"; ?>
<?php $cur = "events"; ?>
<?php include_once("template/header.php"); ?>

<div id="main">
			
		<div class="row">
			
			<article>		
				<?php include("pulsepro/data/blocks/Events/Current-Month.html"); ?>
			</article>		
				
		</div>
		
</div>

<?php include_once("template/footer.php"); ?>