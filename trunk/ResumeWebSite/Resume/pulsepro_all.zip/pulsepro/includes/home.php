<?php $on='backup'; ?>

<div id="content">
	            
<div class="home-icon">	 
<a href="index.php?p=blocks">           
<div class="home-inner blocks-icon"></div>
<p><?php echo $lang_nav_blocks; ?></p></a>
</div>

<div class="home-icon">	  
<a href="index.php?p=manage-blog">          
<div class="home-inner blog-icon"></div>
<p><?php echo $lang_nav_blog; ?></p></a>
</div>

<div class="home-icon">	   
<a href="index.php?p=manage-gallery">         
<div class="home-inner gallery-icon"></div>
<p><?php echo $lang_nav_galleries; ?></p></a>
</div>

<div class="home-icon">	 
<a href="index.php?p=stats">           
<div class="home-inner stats-icon"></div>
<p><?php echo $lang_nav_stats; ?></p></a>
</div>

<div class="home-icon">	    
<a href="index.php?p=manage-form">        
<div class="home-inner form-icon"></div>
<p><?php echo $lang_nav_form ; ?></p></a>
</div>

<div class="home-icon">	
<a href="index.php?p=list-backups">            
<div class="home-inner backup-icon"></div>
<p><?php echo $lang_nav_backup; ?></p></a>
</div>

<div class="home-icon">	  
<a href="index.php?p=settings">          
<div class="home-inner settings-icon"></div>
<p><?php echo $lang_nav_settings; ?></p></a>
</div>

</div>