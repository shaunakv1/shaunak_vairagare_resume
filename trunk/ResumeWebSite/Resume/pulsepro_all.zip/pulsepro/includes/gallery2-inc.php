<script src="http://<?php echo $_SERVER['HTTP_HOST'] ?>/<?php echo $pulse_dir?>/plugins/jquery/jquery.min.js"></script>
<script src="http://<?php echo $_SERVER['HTTP_HOST'] ?>/<?php echo $pulse_dir?>/plugins/slimbox/js/slimbox2.js"></script>
<link rel="stylesheet" href="http://<?php echo $_SERVER['HTTP_HOST'] ?>/<?php echo $pulse_dir?>/plugins/slimbox/css/slimbox2.css" type="text/css" media="screen" />
