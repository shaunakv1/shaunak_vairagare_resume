</div>

<div id="footer">

<a class="ver" target="_blank" href="http://pulsecms.com/download.php">Pulse Pro 2.3</a>
<a class="help" target="_blank" href="http://pulsecms.com/support.php"><?php echo $lang_help; ?></a>

</div>

</body>

</html>