<?php 
$on='form'; 
?>

<?php $question = array_rand($questions, 1); ?>

<div id="sub-head">
<a href="index.php?p=home"><?php echo $lang_go_back; ?></a>
<a href="index.php?p=settings"><?php echo $lang_nav_settings; ?></a>
</div>

<div id="content">

<link rel="stylesheet" href="css/form.css" media="all">

<ul class="form-preview">
<li><?php echo $lang_form_preview_only; ?></li>
<li><?php echo $lang_form_destination_email; ?></li>
<li><?php echo $lang_form_style; ?></li>
</ul><br>

<form id="contact" method="post">

<fieldset>
<label for="name"><?php echo $lang_form_label_name; ?></label><br>
<input id="name" name="name" type="text" value="<?php echo stripslashes(strip_tags($_POST['name'])); ?>" >
</fieldset>

<fieldset>
<label for="email"><?php echo $lang_form_label_email; ?></label><br>
<input id="email" name="email" type="email" value="<?php echo stripslashes(strip_tags($_POST['email'])); ?>" >
</fieldset>

<!-- Custom Field 1 -->
<?php  if(!empty($custom_fieldname1)) {?>
<fieldset>
<label for="custom1"><?php echo "$custom_fieldname1"; ?></label><br>
<input id="custom1" name="custom1" type="text" value="<?php echo stripslashes(strip_tags($_POST['custom1'])); ?>" >
</fieldset>
<?php } ?>

<!-- Custom Field 2 -->
<?php  if(!empty($custom_fieldname2)) {?>
<fieldset>
<label for="custom2"><?php echo "$custom_fieldname2"; ?></label><br>
<input id="custom2" name="custom2" type="text" value="<?php echo stripslashes(strip_tags($_POST['custom2'])); ?>" >
</fieldset>
<?php } ?>

<fieldset>
<input id="human" name="human" type="text" value="<?php echo stripslashes(strip_tags($_POST['human']));?>" >  
<label for="comment"><?php echo $lang_form_label_comment; ?></label><br>
<textarea id="comment" name="comment" rows="8"><?php echo stripslashes(strip_tags($_POST['comment'])); ?></textarea>
</fieldset>

<fieldset>
<label for="name"><?php echo $question; ?> </label> 
<input type="hidden" name="token" value="<?php echo md5($answer); ?>" >
<input type="hidden" name="question" value="<?php echo $question; ?>" >
<input id="name" type="text" name="answers" />
</fieldset>

<button class="btn"><?php echo $lang_form_send; ?></button>

</form>

<div class="howto">
	<a href="javascript:doMenu('main');" id=xmain><?php echo $lang_embed; ?></a>
	<div id="main" style="display:none;">
	<p><?php echo $lang_embed_desc; ?></p>
	<input value='&lt;?php include("<?php echo $pulse_dir; ?>/includes/form.php"); ?&gt;' onclick="select_all(this)" > 
	<br><?php echo $lang_embed_desc2; ?>
	</div>
</div>

</div>