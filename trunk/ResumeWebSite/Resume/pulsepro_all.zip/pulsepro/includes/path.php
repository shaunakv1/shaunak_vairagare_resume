<?php 
define('ROOTPATH', dirname(dirname(__FILE__))); 
$server_time = md5($_SERVER['HTTP_HOST']);
?>