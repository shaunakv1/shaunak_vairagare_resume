<?php 
error_reporting(0);
include('config.php'); 
include_once("path.php");

if($pulse_lang == 0){
include_once("lang.php");}
else
if($pulse_lang == 1){
include_once("lang_de.php");}
?>
<!DOCTYPE html> 
<html> 

<head> 
	<title><?php echo $lang_gal_gallery_preview; ?></title> 
	<meta charset="utf-8" /> 
	<style type="text/css">
	
body {
	background-color: #f5f5f5;
	font-family: sans-serif;
	font-size: 14px;
	color: #333;
}

.wrap {
	max-width: 600px;
	margin-left: auto;
	margin-right: auto;
	padding: 10px;
	margin-top: 30px;
}

a {
	color: #444;
	text-decoration: none;
}

.close {
	background-color: white;
	padding: 7px 15px;
	border-radius: 4px;
	border-color: #ddd;
	border-style: solid;
	border-width: 1px;
}

h3 {
	margin-bottom: 25px;
	padding-bottom: 7px;
	color: #444;
	border-bottom: 2px solid #e5e5e5;
}
	</style>
</head> 
	
<body id="gal-prev"> 

<div class="wrap">

<a class="close" href="" onclick="window.open('', '_self', ''); window.close();"><?php echo $lang_gal_close_preview; ?></a>

<br><br><br>

<h3><?php echo $lang_gal_preview_thumb_preview; ?></h3>

<?php include_once("gallery2.php"); ?>

<br><br><br>

<h3><?php echo $lang_gal_preview_slider_preview; ?></h3>

<?php include_once("gallery.php"); ?>

</div>
	
</body> 
	
</html>